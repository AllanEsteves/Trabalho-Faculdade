from flask import Flask
from flask import render_template
app=Flask(__name__)

@app.route("/index.html")
def index():
    return render_template("index.html")

@app.route("/index2.html")   
def index2():
    return render_template("index2.html")

@app.route("/index3.html")
def index3():
    return render_template("index3.html")

@app.route("/index4.html")
def index4():
    return render_template("index4.html")

app.run()


#"http://127.0.0.1:5000/home" #enderco URL

#localhost:5000/home  # outro caminho q da pra por de URL